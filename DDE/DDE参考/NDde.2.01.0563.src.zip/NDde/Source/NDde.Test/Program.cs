using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using NDde;
using NDde.Advanced;
using NDde.Advanced.Monitor;
using NDde.Client;
using NDde.Server;

namespace NDde.Test
{
    class Program
    {
        static void Main(string[] args)
        {
        }

    } // class

} // namespace
