Trade-via.DDE
=============

get real time tick data viaDDE from any DDE supported Trading platform, MT4, Trading API .NET C#


Todo

add api to exchange , a BrokerPlugin to communicate with API for trading from Trade.Via.DDE UI

Fix 

- binddata without threading issues, ( event handle ) DDE , onAdivse() 
- IList or add dataSet database mySQL or SQL server to collect streaming tick data
